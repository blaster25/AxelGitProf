angular.module('profiler.controllers', [])

.controller('addProfileCtrl', function($scope, $rootScope,$ionicScrollDelegate) {
  $rootScope.addProfileVisible = true;
  $scope.date = new Date();
  $scope.addMemberFormVisible = false;
  $scope.addPatternForm = true;


  // var obj_dump = function obj_dump(obj,mode=false) 
  // {
  //   var out = '';
  //   for (var i in obj) 
  //     {out += i + ": " + obj[i] + "\n";};
      
  //     if (mode) {alert(out);       }
  //     else      {console.log(out);  };
      
  // };



  var obj_dump = function obj_dump(obj) 
  {
    var out = '';
    for (var i in obj) 
      {out += i + ": " + obj[i] + "\n";};
      
     alert(out);
      
  };


  // Evaluators and Imploders! <START>

  $scope.eval_A1_1 = function eval_A1_1(){
    if($scope.surveyRaw.A1_entryPass){$scope.surveyInput.A1_entryPass="Entry Pass"}
    else{$scope.surveyInput.A1_entryPass=""};
  };

  $scope.eval_A1_2 = function eval_A1_2(){
    if($scope.surveyRaw.A1_certificate){$scope.surveyInput.A1_certificate="Certificate"}
    else{$scope.surveyInput.A1_certificate=""};
  };

  $scope.eval_A4 = function eval_A4(){
    if ($scope.surveyInput.A4_reasonForReloc=="Others") {$scope.surveyRaw.A4_others=true;}
    else{$scope.surveyRaw.A4_others=false;};
  };

  $scope.eval_A6 = function eval_A6(){
    if ($scope.surveyInput.A6_waterSource=="Others") {$scope.surveyRaw.A6_others=true;}
    else{$scope.surveyRaw.A6_others=false;};
  };

  $scope.eval_A9 = function eval_A9(){
    if ($scope.surveyInput.A9_typeOfAlterations=="Others") {$scope.surveyRaw.A9_others=true;}
    else{$scope.surveyRaw.A9_others=false;};
  };



  $scope.eval_B1 = function eval_B1(){
    if ($scope.bGroupInput.B1_relationToHhH=="Others") {$scope.bGroupRaw.B1_others=true;}
    else{$scope.bGroupRaw.B1_others=false;};
  };

  $scope.eval_B7 = function eval_B7(){
    if ($scope.bGroupInput.B7_occupation=="Others") {$scope.bGroupRaw.B7_others=true;}
    else{$scope.bGroupRaw.B7_others=false;};
  };

  $scope.eval_B8 = function eval_B8(){
    if ($scope.bGroupInput.B8_stateOfOccupation=="Others") {$scope.bGroupRaw.B8_others=true;}
    else{$scope.bGroupRaw.B8_others=false;};
  };

  $scope.eval_B9 = function eval_B9(){
    if ($scope.bGroupInput.B9_placeOfWork=="Others") {$scope.bGroupRaw.B9_others=true;}
    else{$scope.bGroupRaw.B9_others=false;};
  };

  $scope.eval_B13 = function eval_B13(){
    if ($scope.bGroupInput.B13_skills=="Others") {$scope.bGroupRaw.B13_others=true;}
    else{$scope.bGroupRaw.B13_others=false;};
  };

  $scope.eval_B14 = function eval_B14(){
    if ($scope.bGroupInput.B14_healthStatus=="Others") {$scope.bGroupRaw.B14_others=true;}
    else{$scope.bGroupRaw.B14_others=false;};
  };


  $scope.implode_A10 = function implode_A10(){
  $scope.surveyRaw.A10 = "";
  if ($scope.surveyRaw.A10_arr[0]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "TV, "};
  if ($scope.surveyRaw.A10_arr[1]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Radio/Component, "};
  if ($scope.surveyRaw.A10_arr[2]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "DVD Player, "};
  if ($scope.surveyRaw.A10_arr[3]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "PC/Laptop, "};
  if ($scope.surveyRaw.A10_arr[4]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Rice Cooker, "};
  if ($scope.surveyRaw.A10_arr[5]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Refrigerator, "};
  if ($scope.surveyRaw.A10_arr[6]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Electric Fan, "};
  if ($scope.surveyRaw.A10_arr[7]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Electric Iron, "};
  if ($scope.surveyRaw.A10_arr[8]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Stove/Oven, "};
  if ($scope.surveyRaw.A10_arr[9]) {$scope.surveyRaw.A10 = $scope.surveyRaw.A10 + "Washing Machine, "};
  };

  $scope.implode_A11 = function implode_A11(){
  $scope.surveyRaw.A11 = "";
  if ($scope.surveyRaw.A11_arr[0]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Car/Pick-up Truck, "};
  if ($scope.surveyRaw.A11_arr[1]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Cargo Truck, "};
  if ($scope.surveyRaw.A11_arr[2]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Jeepney/Multicab, "};
  if ($scope.surveyRaw.A11_arr[3]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Motorcycle, "};
  if ($scope.surveyRaw.A11_arr[4]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Motorela, "};
  if ($scope.surveyRaw.A11_arr[5]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Bicycle, "};
  if ($scope.surveyRaw.A11_arr[6]) {$scope.surveyRaw.A11 = $scope.surveyRaw.A11 + "Tri-sikad, "};
  console.log($scope.surveyRaw.A11);
  };

  $scope.implode_B11 = function implode_B11(){
  $scope.bGroupInput.B11_membersInInstitutions = "";
  if ($scope.bGroupRaw.B11_arr[0]) {$scope.bGroupInput.B11_membersInInstitutions = $scope.bGroupInput.B11_membersInInstitutions + "GSIS, "};
  if ($scope.bGroupRaw.B11_arr[1]) {$scope.bGroupInput.B11_membersInInstitutions = $scope.bGroupInput.B11_membersInInstitutions + "SSS, "};
  if ($scope.bGroupRaw.B11_arr[2]) {$scope.bGroupInput.B11_membersInInstitutions = $scope.bGroupInput.B11_membersInInstitutions + "PAGIBIG, "};
  if ($scope.bGroupRaw.B11_others) {$scope.bGroupInput.B11_membersInInstitutions = $scope.bGroupInput.B11_membersInInstitutions + $scope.bGroupRaw.B11_arr[3]};

  
  };

  $scope.implode_B12 = function implode_B12(){
  $scope.bGroupInput.B12_beneficiary = "";
  if ($scope.bGroupRaw.B12_arr[0]) {$scope.bGroupInput.B12_beneficiary = $scope.bGroupInput.B12_beneficiary + "4Ps, "};
  if ($scope.bGroupRaw.B12_arr[1]) {$scope.bGroupInput.B12_beneficiary = $scope.bGroupInput.B12_beneficiary + "PhilHealth, "};
  if ($scope.bGroupRaw.B12_arr[2]) {$scope.bGroupInput.B12_beneficiary = $scope.bGroupInput.B12_beneficiary + "Livelihood, "};
  if ($scope.bGroupRaw.B12_arr[3]) {$scope.bGroupInput.B12_beneficiary = $scope.bGroupInput.B12_beneficiary + "Training, "};
  if ($scope.bGroupRaw.B12_others) {$scope.bGroupInput.B12_beneficiary = $scope.bGroupInput.B12_beneficiary + $scope.bGroupRaw.B12_arr[4]};

  
  };

  $scope.eval_bGroup = function eval_bGroup(){
    console.log("Number of members: " + Object.keys($scope.bGroup).length);
    // console.log($scope.bGroup);
  };

  // Evaluators and Imploders! <END>
  $scope.surveyInput=
  {
    A1_entryPass:                       null,
    A1_certificate:                     null,
    A2_blockNumber:                     null,
    A2_lotNumber:                       null,
    A2_houseNumber:                     null,
    A3_occupant:                        null,
    A3_hh:                              null,
    A4_reasonForReloc:                  null,
    A5_placeOfOrigin:                   null,
    A6_waterSource:                     null,
    A7_electricity:                     null,
    A8_houseAlterations:                null,
    A9_typeOfAlterations:               null,
    A10_householdAmenities:             "",
    A11_vehicles:                       "",
    A12_remarks:                        null,
    C1:                                 null,
    C2:                                 null,
    C3:                                 null,
    C4:                                 null,
    D1_water:                           null,
    D2_electricity:                     null,
    D3_garabageCollection:              null,
    D4_toiletFacilities:                null,
    D5_healthCenter:                    null,
    D6_privateHealthClinics:            null,
    D7_traditionalHealersAlternative:   null,
    D8_dayCareCenterPreSChool:          null,
    D9_elementarySchool:                null,
    D10_highSchool:                     null,
    D11_marketTalipapa:                 null,
    D12_baraggayHall:                   null,
    D13_policeOutpost:                  null,
    D14_recreationalFacilities:         null,
    D15_publicTransport:                null,
    D16_remarks:                        null,
    E1_f1:                              null,
    E1_details:                         null,
    E2_balayDate:                       null,
    E3:                                 null,
    E4_remarks:                         null,
  };

  $scope.surveyRaw=
  {
    A1_entryPass:                       null,
    A1_certificate:                     null,
    A2_blockNumber:                     null,
    A2_lotNumber:                       null,
    A2_houseNumber:                     null,
    A3_occupant:                        null,
    A3_hh:                              null,
    A4_reasonForReloc:                  null,
    A4_others:                          false,
    A5_placeOfOrigin:                   null,
    A6_waterSource:                     null,
    A6_others:                          false,
    A7_electricity:                     null,
    A8_houseAlterations:                null,
    A9_typeOfAlterations:               null,
    A10_arr:                            new Array(),
    A10:                                "",
    A11_arr:                            new Array(),
    A11:                                "",
    A12_remarks:                        null,
    C1:                                 null,
    C2:                                 null,
    C3:                                 null,
    C4:                                 null,
    D1_water:                           null,
    D2_electricity:                     null,
    D3_garabageCollection:              null,
    D4_toiletFacilities:                null,
    D5_healthCenter:                    null,
    D6_privateHealthClinics:            null,
    D7_traditionalHealersAlternative:   null,
    D8_dayCareCenterPreSChool:          null,
    D9_elementarySchool:                null,
    D10_highSchool:                     null,
    D11_marketTalipapa:                 null,
    D12_baraggayHall:                   null,
    D13_policeOutpost:                  null,
    D14_recreationalFacilities:         null,
    D15_publicTransport:                null,
    D16_remarks:                        null,
    E1_f1:                              null,
    E1_details:                         null,
    E2_balayDate:                       null,
    E3:                                 null,
    E4_remarks:                         null,
  };


  $scope.bGroup = new Array();

  // $scope.bGroup[0] =
  // {
  //   firstName                : "Jebb Matthew",
  //   lastName                 : "Luza",
  //   middleName               : "Paderon",
  //   B1_relationToHhH         : "House Hold Head",
  //   B2_sex                   : "null",
  //   B3_dob                   : "null",
  //   B4_birthplace            : "null",
  //   B5_maritalStatus         : "null",
  //   B6_education             : "null",
  //   B7_occupation            : "null",
  //   B8_stateOfOccupation     : "null",
  //   B9_placeOfWork           : "null",
  //   B10_monthlyIncome        : "null",
  //   B11_membersInInstitutions: "null",
  //   B12_beneficiary          : "null",
  //   B13_skills               : "null",
  //   B14_healthStatus         : "null",
  //   B15_status               : "null",
  //   B16_remarks              : "null",    
  // };

  // $scope.bGroupInput = {};




  $scope.bGroupInput = 
  {

    firstName                : null,
    lastName                 : null,
    middleName               : null,
    B1_relationToHhH         : null,
    B2_sex                   : "Male",
    B3_dob                   : null,
    B4_birthplace            : null,
    B5_maritalStatus         : "Single",
    B6_education             : "None",
    B7_occupation            : "None",
    B8_stateOfOccupation     : "None",
    B9_placeOfWork           : "None",
    B10_monthlyIncome        : null,
    B11_membersInInstitutions: "None",
    B12_beneficiary          : "None",
    B13_skills               : "None",
    B14_healthStatus         : null,
    B15_status               : null,
    B16_remarks              : null,
  };  
  console.log($scope.bGroupInput);

  $scope.bGroupRaw = {
    B1_relationToHhH         :null,
    B1_others                :false,
    B7_occupation            :null,
    B7_others                :false,
    B8_stateOfOccupation     :null,
    B8_others                :false,
    B9_placeOfWork           :null,
    B9_others                :false,
    B11                      :null,
    B11_others               :false,
    B11_arr                  :new Array(),
    B12                      :null,
    B12_others               :false,
    B12_arr                  :new Array(),
    B13_skills               :null,
    B13_others               :null,
    B14_healthStatus         :null,
    B14_others               :false,
    B15_status               :null,
    B16_remarks              :null,
  };

  $scope.test = function saveMemberTo_bGroup()
  {
    if (Object.keys($scope.bGroup).length == 0) 
    {
      $scope.bGroupInput.B1_relationToHhH = "House Hold Head";
      console.log($scope.bGroupInput.B1_relationToHhH + "auto selected");
    };

    if ($scope.bGroupInput.B1_relationToHhH=="Others")
    {$scope.bGroupInput.B1_relationToHhH = $scope.bGroupRaw.B1_relationToHhH;};
    
    if ($scope.bGroupInput.B7_occupation=="Others")
    {$scope.bGroupInput.B7_occupation = $scope.bGroupRaw.B7_occupation;};
    
    if ($scope.bGroupInput.B8_stateOfOccupation=="Others")
    {$scope.bGroupInput.B8_stateOfOccupation = $scope.bGroupRaw.B8_stateOfOccupation;};
    
    if ($scope.bGroupInput.B9_placeOfWork=="Others")
    {$scope.bGroupInput.B9_placeOfWork = $scope.bGroupRaw.B9_placeOfWork;};
    
    if ($scope.bGroupInput.B13_skills=="Others")
    {$scope.bGroupInput.B13_skills = $scope.bGroupRaw.B13_skills;};
    
    if ($scope.bGroupInput.B14_healthStatus=="Others")
    {$scope.bGroupInput.B14_healthStatus = $scope.bGroupRaw.B14_healthStatus;};

    $scope.implode_B11();
    $scope.implode_B12();

    obj_dump($scope.bGroupInput);

    $scope.bGroup.push($scope.bGroupInput);

  };

})

.controller('viewProfileCtrl', function($scope, Profiles) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.profiles = Profiles.all();
  console.log($scope.profiles);
  $scope.remove = function(profile) {
    Profiles.remove(profile);
  };
})

.controller('viewProfileDetailCtrl', function($scope, $stateParams, Profiles) {
  $scope.profile = Profiles.get($stateParams.profileId);
})

.controller('settingsCtrl', function($scope, $rootScope) {
  
  $rootScope.surveySettings={
    AOS:null,
    AC:null,
  };
  
  $scope.surveySettingsSave = function surveySettingsSave(){
    if ($rootScope.surveySettings.AOS !== null && $rootScope.surveySettings.AC !== null &&  $rootScope.surveySettings.AOS !== "" && $rootScope.surveySettings.AC !== "") 
      {
        $rootScope.addProfileVisible = true;
      }
    else
      {
        $rootScope.addProfileVisible = false;        
      }

  };

  
  
  $scope.surveySettingsForm = true;  
  $scope.uploadSettingsForm = true;  
  $scope.settings = {
    enableFriends: true
  };
});
